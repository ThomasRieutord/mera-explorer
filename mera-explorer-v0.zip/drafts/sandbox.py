#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""The Met Eireann ReAnalysis explorer.

Sandbox.
"""

import os
import numpy as np
from pprint import pprint
import datetime as dt
from mera_explorer import (
    gribs,
    utils,
    data,
    _repopath_
)

atm_variables = data.neurallam.all_variables

fstxt = os.path.join(_repopath_, "reaext", "merafiles_reaext03.txt")
# fstxt = os.path.expanduser("allmerafiles.txt")

with open(fstxt, "r") as f:
    ll = f.readlines()

merafilenames = []
for l in ll:
    if l.startswith("MERA"):
        merafilenames.append(l.strip())

iop_itl_lev_tri = [
    "_".join([str(d) for d in gribs.get_grib1id_from_cfname(cfname)])
    for cfname in atm_variables
]

herevarnames = []
print("\nVAR.CODE \t VAR.NAME                                \t #FILES")
print("--------- \t ---------                                \t ---------")
for varcode, varname in zip(iop_itl_lev_tri, atm_variables):
    n_files_here = len([_ for _ in merafilenames if varcode in _])
    print(f"{varcode} \t {varname.ljust(40)} \t {n_files_here} files for this variable in this filesystem")
    
    if n_files_here > 0:
        herevarnames.append(varname)


# Identify the files to transfer
#--------------------------------
valtimes = utils.datetime_arange("2017-09-15", "2017-11-15", "3h")
heregribnames = gribs.get_all_mera_gribnames(herevarnames, valtimes, pathfromroot = True)
print(f"To extract {len(herevarnames)} variables for {len(valtimes)} validity times, we need {len(heregribnames)} GRIB files:")
print(heregribnames)
rootdir = "/run/media/trieutord/reaext03"
total_memory = 0
for fn in heregribnames:
    if os.path.isfile(os.path.join(rootdir, fn)):
        src_path = os.path.join(rootdir, fn)
        bz2 = False
    elif os.path.isfile(os.path.join(rootdir, fn + ".bz2")):
        src_path = os.path.join(rootdir, fn + ".bz2")
        bz2 = True
    else:
        print(f"Missing file {os.path.join(rootdir, fn)}")
        continue
    
    total_memory += os.path.getsize(src_path)
    print(f"File {src_path} -\t {os.path.getsize(src_path)/10**6} MB")

print(f"Total: {total_memory/10**9} GB")
